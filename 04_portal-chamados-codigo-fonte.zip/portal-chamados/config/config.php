<?php
/**
 * Configuração da aplicação.
 * Os valores podem ser sobrescritos por variáveis de ambiente (ver .env.example).
 */
$env = static fn(string $k, $padrao) => getenv($k) !== false ? getenv($k) : $padrao;

// Carrega .env simples (chave=valor), se existir na raiz do projeto
$arquivoEnv = dirname(__DIR__) . '/.env';
if (is_file($arquivoEnv)) {
    foreach (file($arquivoEnv, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linha) {
        if (str_starts_with(trim($linha), '#') || !str_contains($linha, '=')) continue;
        [$k, $v] = array_map('trim', explode('=', $linha, 2));
        if (getenv($k) === false) putenv("$k=$v");
    }
}

return [
    'app_nome'     => 'Portal de Chamados Polenta TI',
    'timezone'     => 'America/Sao_Paulo',
    'db' => [
        'host'  => $env('DB_HOST', '127.0.0.1'),
        'porta' => $env('DB_PORT', '3306'),
        'nome'  => $env('DB_NAME', 'portal_chamados'),
        'user'  => $env('DB_USER', 'root'),
        'senha' => $env('DB_PASS', ''),
    ],
    // Expediente usado no cálculo do SLA (horas úteis)
    'expediente' => ['inicio' => 8, 'fim' => 17, 'dias' => [1, 2, 3, 4, 5]],
    'upload_dir'       => dirname(__DIR__) . '/storage/uploads',
    'upload_max_bytes' => 10 * 1024 * 1024,
    'upload_tipos'     => ['image/png', 'image/jpeg', 'image/gif', 'application/pdf', 'text/plain',
                           'application/zip', 'application/x-zip-compressed'],
];
